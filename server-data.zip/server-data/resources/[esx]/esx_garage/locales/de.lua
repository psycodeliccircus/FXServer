Locales['de'] = {
	['veh_released'] = 'Fahrzeug ~g~genommen',
	['veh_stored'] = 'vehicle ~g~geparkt',
	['veh_health'] = 'you\'ll have to repair the vehicle before storing it.',
}
