## ESX CruiseControl

CruiseControl System for ESX Framework.

Press **Y** to activate it.

### Installation

**Using [fvm](https://github.com/qlaffont/fvm-installer).**
```bash
fvm install --save esx_cruisecontrol
```

**Using Git Releases**
Download the latest release : https://github.com/ESX-Org/esx_cruisecontrol/releases
