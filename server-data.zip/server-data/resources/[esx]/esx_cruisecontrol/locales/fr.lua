Locales['fr'] = {
  ['activated']   = 'activé',
  ['deactivated'] = 'désactivé',
}
