Locales['pl'] = {
	
	['used_beer'] = 'używasz 1x ~y~Piwo~s~',

}