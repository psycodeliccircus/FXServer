Locales['fi'] = {
	
	['used_beer'] = 'sinä joit 1x ~y~Olut~s~',

}