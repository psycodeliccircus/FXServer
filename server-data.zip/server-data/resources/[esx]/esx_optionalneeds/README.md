# esx_optionalneeds
ESX Optional Needs

[REQUIREMENTS]
- esx_status https://github.com/ESX-Org/esx_status

[INSTALLATION]

1) CD in your resources folder
2) Clone the repository
```
git clone https://github.com/ESX-Org/esx_optionalneeds [esx]/esx_optionalneeds
```
3) Add this in your server.cfg :

```
start esx_optionalneeds
```
