Locales['br'] = {
  ['valid_purchase'] = 'validar esta compra?',
  ['yes'] = 'sim',
  ['no'] = 'não',
  ['not_enough_money'] = 'você não tem dinheiro suficiente',
  ['press_access'] = 'pressione ~INPUT_CONTEXT~ para acessar o menu',
  ['barber_blip'] = 'Barbearia',
  ['you_paid'] = 'você pagou $%s',
}
