Locales['es'] = {
  ['new_message'] = '~b~Nuevo menaje :~s~ %s',
  ['press_take_call'] = '%s - Presionar ~INPUT_CONTEXT~ para coger la llamada',
  ['taken_call'] = '~y~%s~s~ has contestado la llamada',
  ['gps_position'] = 'posición GPS',
  ['message_sent'] = 'mensaje enviado',
  ['cannot_add_self'] = 'no has podido agregar',
  ['number_in_contacts'] = 'este número ya está en tu lista de contactos',
  ['contact_added'] = 'contacto añadido',
  ['contact_removed'] = 'the contact has been removed!',
  ['number_not_assigned'] = 'el número no se ha añadido todavía...',
  ['invalid_number'] = 'that\'s not an valid number!',
}
