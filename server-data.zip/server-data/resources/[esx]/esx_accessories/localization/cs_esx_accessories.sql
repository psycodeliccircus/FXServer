USE `es_extended`;

INSERT INTO `datastore` (name, label, shared) VALUES
	('user_ears', 'Usi', 0),
	('user_glasses', 'Bryle', 0),
	('user_helmet', 'Helma', 0),
	('user_mask', 'Maska', 0)
;
