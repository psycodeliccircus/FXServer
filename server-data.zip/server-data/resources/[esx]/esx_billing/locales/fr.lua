Locales['fr'] = {
  ['invoices'] = 'factures',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'vous avez ~r~reçu~s~ une facture',
  ['paid_invoice'] = 'vous avez ~g~payé~s~ une facture de ~r~$%s~s~',
  ['no_invoices'] = 'you do not have any bills to pay at this moment',
  ['received_payment'] = 'vous avez ~g~reçu~s~ un paiement de ~g~$%s~s~',
  ['player_not_online'] = 'le joueur n\'est pas connecté',
  ['no_money'] = 'you do not have enough money to pay this bill',
  ['target_no_money'] = 'the player ~r~does not~s~ have enough money to pay the bill!',
  ['keymap_showbills'] = 'open bills menu',
}
